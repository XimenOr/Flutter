import 'package:flutter/material.dart';
import 'lista_productos.dart';

class Carrito extends StatefulWidget {
  final List<ListaProductos> _cart;

  const Carrito(this._cart, {super.key});

  @override
  _CarritoState createState() => _CarritoState(this._cart);
}

class _CarritoState extends State<Carrito> {
  _CarritoState(this._cart);

  List<ListaProductos> _cart;

  var val = 0;
  var val1 = 0;
  var val2 = 0;
  var val3 = 0;
  var val4 = 0;
  var val5 = 0;
  var subtotal = 0;

  var subpro = 0;
  var subpro1 = 0;
  var subpro2 = 0;
  var subpro3 = 0;
  var subpro4 = 0;

  var iva = 0;
  var iva1 = 0;
  var iva2 = 0;
  var iva3 = 0;
  var iva4 = 0;

  var total = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal[200],
      appBar: AppBar(
        backgroundColor: Colors.pink[100],
        title: const Text(
          'Detalle De Compra',
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: Colors.black
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
            setState(() {
              _cart.length;
            });
          },
          color: Colors.black ,
        ),
      ),
      body: GestureDetector(
          child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  ListView.builder(
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _cart.length,
                    itemBuilder: (context, index) {
                      return Card(
                        elevation: 5,
                        margin: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 9
                        ),
                        child: Column(
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 200,
                                  height: 200,
                                  child: Image(
                                    image: NetworkImage(
                                        _cart[index].imageURL.toString()
                                    ),
                                    fit: BoxFit.fill,
                                  ),
                                ),
                                Expanded(
                                    child: Container(
                                      padding: const EdgeInsets.only(bottom: 8),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment
                                            .center,
                                        crossAxisAlignment: CrossAxisAlignment
                                            .start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 8,
                                                right: 8
                                            ),
                                            child: Center(
                                              child: Text(
                                                _cart[index].nombre.toString(),
                                                style: const TextStyle(
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  ),
                                if (_cart[index].id.toInt() == 0) ...[
                                  Row(
                                    children: <Widget>[
                                      Column(
                                          children: [
                                            Text('$subpro')
                                          ]
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.remove_circle_outline_rounded,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          restar();
                                        },
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 14.0),
                                        child: Text('$val',
                                          style: TextStyle(
                                              fontWeight:
                                              FontWeight.bold,
                                              fontSize: 14.0),
                                        ),
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.add_circle_outline_outlined,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          sumar();
                                        },
                                      ),
                                    ],
                                  ),
                                ] else if(_cart[index].id.toInt() == 1)...[
                                  Row(
                                    children: <Widget>[
                                      Column(
                                          children: [
                                            Text('$subpro1')
                                          ]
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.remove_circle_outline_rounded,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          restar1();
                                        },
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 14.0),
                                        child: Text('$val1',
                                          style: TextStyle(
                                              fontWeight:
                                              FontWeight.bold,
                                              fontSize: 14.0),
                                        ),
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.add_circle_outline_outlined,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          sumar1();
                                        },
                                      ),
                                    ],
                                  ),
                                ] else if(_cart[index].id.toInt() == 2)...[
                                  Row(
                                    children: <Widget>[
                                      Column(
                                          children: [
                                            Text('$subpro2')
                                          ]
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.remove_circle_outline_rounded,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          restar2();
                                        },
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 14.0),
                                        child: Text('$val2',
                                          style: TextStyle(
                                              fontWeight:
                                              FontWeight.bold,
                                              fontSize: 14.0),
                                        ),
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.add_circle_outline_outlined,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          sumar2();
                                        },
                                      ),
                                    ],
                                  ),
                                ] else if(_cart[index].id.toInt() == 3)...[
                                  Row(
                                    children: <Widget>[
                                      Column(
                                          children: [
                                            Text('$subpro3')
                                          ]
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.remove_circle_outline_rounded,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          restar3();
                                        },
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 14.0),
                                        child: Text('$val3',
                                          style: TextStyle(
                                              fontWeight:
                                              FontWeight.bold,
                                              fontSize: 14.0),
                                        ),
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.add_circle_outline_outlined,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          sumar3();
                                        },
                                      ),

                                    ],
                                  ),
                                ] else if(_cart[index].id.toInt() == 4)...[
                                  Row(
                                    children: <Widget>[
                                      Column(
                                          children: [
                                            Text('$subpro4')
                                          ]
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.remove_circle_outline_rounded,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          restar4();
                                        },
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 14.0),
                                        child: Text('$val4',
                                          style: TextStyle(
                                              fontWeight:
                                              FontWeight.bold,
                                              fontSize: 14.0),
                                        ),
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.add_circle_outline_outlined,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          sumar4();
                                        },
                                      ),
                                    ],
                                  ),
                                ] else if(_cart[index].id.toInt() == 5)...[
                                  Row(
                                    children: <Widget>[
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.remove_circle_outline_rounded,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          restar5();
                                        },
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 14.0),
                                        child: Text('$val5',
                                          style: TextStyle(
                                              fontWeight:
                                              FontWeight.bold,
                                              fontSize: 14.0),
                                        ),
                                      ),
                                      GestureDetector(
                                        child: Container(
                                          width: 18.0,
                                          height: 18.0,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadiusDirectional
                                                .circular(3.0),
                                          ),
                                          child: Icon(
                                            Icons.add_circle_outline_outlined,
                                            size: 14.0,
                                          ),
                                        ),
                                        onTap: () {
                                          sumar5();
                                        },
                                      ),
                                      Row(
                                        children: [
                                          Text('$subtotal')
                                        ],
                                      )
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  Container(
                      child: Column(
                        children: [
                          Text('Subtotal $subtotal'),
                          Text('IVA $iva'),
                          Text('Total $total'),
                        ],
                      )
                  ),

                ],
              ),

          ),
      ),
    );
  }


  void sumar() {
    setState(() {
      val = val + 1;
      subtotal = subtotal + 40000;
      subpro = subpro + 40000;
      iva = (subpro * 19 / 100) as int;
      total = (subpro + iva);
    });
  }

  void restar() {
    setState(() {
      if (val != 0) {
        val = val - 1;
        subtotal = subtotal - 40000;
        subpro = subpro - 40000;
        iva = (subpro * 19 / 100) as int;
        total = (subpro + iva);
      }
    });
  }

  void sumar1() {
    setState(() {
      val1 = val1 + 1;
      subtotal = subtotal + 25000;
      subpro1 = subpro1 + 25000;
      iva = (subpro1 * 19 / 100) as int;
      total = (subpro1 + iva);
    });
  }

  void restar1() {
    setState(() {
      if (val1 != 0) {
        val1 = val1 - 1;
        subtotal = subtotal - 25000;
        subpro1 = subpro1 - 25000;
        iva = (subpro1 * 19 / 100) as int;
        total = (subpro + iva);
      }
    });
  }

  void sumar2() {
    setState(() {
      val2 = val2 + 1;
      subtotal = subtotal + 12000;
      subpro2 = subpro2 + 12000;
      iva = (subpro2 * 19 / 100) as int;
      total = (subpro2 + iva);
    });
  }

  void restar2() {
    setState(() {
      if (val2 != 0) {
        val2 = val2 - 1;
        subtotal = subtotal - 12000;
        subpro2 = subpro2 - 12000;
        iva = (subpro2 * 19 / 100) as int;
        total = (subpro + iva);
      }
    });
  }

  void sumar3() {
    setState(() {
      val3 = val3 + 1;
      subtotal = subtotal + 25000;
      subpro3 = subpro3 + 25000;
      iva = (subpro3 * 19 / 100) as int;
      total = (subpro3 + iva);
    });
  }

  void restar3() {
    setState(() {
      if (val3 != 0) {
        val3 = val3 - 1;
        subtotal = subtotal - 25000;
        subpro3 = subpro3 - 25000;
        iva = (subpro3 * 19 / 100) as int;
        total = (subpro3 + iva);
      }
    });
  }

  void sumar4() {
    setState(() {
      val4 = val4 + 1;
      subtotal = subtotal + 17000;
      subpro4 = subpro4 + 17000;
      iva = (subpro4 * 19 / 100) as int;
      total = (subpro4 + iva);

    });
  }

  void restar4() {
    setState(() {
      if (val4 != 0) {
        val4 = val4 - 1;
        subtotal = subtotal - 17000;
        subpro4 = subpro4 - 17000;
        iva = (subpro4 * 19 / 100) as int;
        total = (subpro4 + iva);
      }

    });
  }

  void sumar5() {
    setState(() {
      val5 = val5 + 1;
    });
  }

  void restar5() {
    setState(() {
      if (val5 != 0) val5 = val5 - 1;
    });
  }

}

