import 'package:flutter/material.dart';
import '../constants.dart';

class MyTile extends StatelessWidget {
  final int cont;

  const MyTile({Key? key, required this.cont}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: 110,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('images/producto${cont + 1}.jpg'),
              alignment: Alignment.topLeft
          ),
          borderRadius: BorderRadius.circular(8),
          color: Colors.grey[200],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            TextButton(onPressed: () {},
              child: (Text('Mas Info', style: TextStyle (color: Colors.deepPurple),)),
            ),
            Center(
              child: Column(
                children: [
                  if (cont == 0) ...[
                    Text("Lampara Conejito"),
                  ] else
                    if(cont == 1)...[
                      Text("Lampara Honguito Mario Bross"),
                    ] else
                      if(cont == 2)...[
                        Text("Lampara De Escritorio Kawaii"),
                      ] else
                        if(cont == 3)...[
                          Text("Reloj Dinosaurio"),
                        ] else
                          if(cont == 4)...[
                            Text("Reloj Oso Panda"),
                          ] else
                            if(cont == 5)...[
                              Text("Reloj Gallina"),
                            ] else
                              if(cont == 6)...[
                                Text("Lampara Nigiri"),
                              ] else
                                if(cont == 7)...[
                                  Text("Lampara Molang"),
                                ] else
                                  if(cont == 8)...[
                                    Text("Lampara Jooba Boba"),
                                  ] else
                                    if(cont == 9)...[
                                      Text("Lampara Gatito"),
                                    ],
                ],
              ),
            ),
            FloatingActionButton(
              onPressed: () {}, backgroundColor: Colors.indigo[200],
              child: Icon(Icons.shopping_cart),
            ),
          ],
        ),
      ),
    );
  }
}