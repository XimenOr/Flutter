import 'package:flutter/material.dart';

var defaultBackgroundColor = Colors.indigo[200];
var appBarColor = Colors.deepPurple[300];
var myAppBar = AppBar(
  backgroundColor: appBarColor,
  title: const Text(''),
  centerTitle: false,
);
var drawerTextColor = TextStyle(
  color: Colors.purple[600],
);
var titlePadding = const EdgeInsets.only(left: 8.0, right: 8, top:8);
var myDrawer = Drawer(
  backgroundColor: Colors.grey[300],
  elevation: 0,
  child: Column(
    children: [
      const DrawerHeader(
        child: CircleAvatar (
         backgroundImage: NetworkImage("../images/perfil.jpg"),
          radius: 70,
        ),
      ),
      Padding(
        padding: titlePadding,
        child: ListTile(
          leading: const Icon(Icons.home),
          title: Text(
            'I N I C I O',
            style: drawerTextColor,
          ),
        ),
      ),
      Padding(
        padding: titlePadding,
        child: ListTile(
          leading: const Icon(Icons.settings),
          title: Text(
            'C O N F I G U R A C I O N',
            style: drawerTextColor,
          ),
        ),
      ),
      Padding(
        padding: titlePadding,
        child: ListTile(
          leading: const Icon(Icons.info),
          title: Text(
              'A Y U D A',
              style: drawerTextColor
          ),
        ),
      ),
      Padding(
        padding: titlePadding,
        child: ListTile(
          leading: const Icon(Icons.logout),
          title: Text(
            'S A L I R',
            style: drawerTextColor,
          ),
        ),
      ),
    ],
  ),
);
