package com.example.portafolio_2_modificado

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
