package com.example.portafolio_de_productos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
