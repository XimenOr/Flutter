import 'package:flutter/material.dart';

class ItemDetailsScreen extends StatelessWidget {
  static const valueKey = ValueKey('ItemDetailScreen');

  final String product;
  final int cont;

  const ItemDetailsScreen({Key? key, required this.product, required this.cont}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalles del producto'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Image.asset("images/pic${cont + 1}.jpg"),
          ),
          Text(
            product,
            style: const TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20.0
            ),
          ),
          if (product == "Producto 1")...[
            Text('Medias Tres Cuartos Unisex'),
              Text('8.000')
          ]
          else if (product == "Producto 2")...[
            Text('Pantuflas Conejo Cute'),
              Text('20.000')
          ]
          else if (product == "Producto 3")...[
            Text('Gorro De Lana'),
              Text('12.000')
            ]
          else if (product == "Producto 4")...[
            Text('Camisa Juego Sin Internet Google'),
                Text('30.000')
              ]
          else if (product == "Producto 5")...[
            Text('Jogger Suelto Mujer'),
                  Text('40.000')
                ]
          else if (product == "Producto 6")...[
            Text('Botas Aesthetic En Cuerina'),
                    Text('130.000')
                  ]
          else if (product == "Producto 7")...[
            Text('Maleta Portatil'),
                      Text('80.000')
                    ]
          else if (product == "Producto 8")...[
            Text('Camisas Aesthetic Unisex'),
                        Text('85.000')
                      ]
          else if (product == "Producto 9")...[
            Text('Beisbolera Negra Unisex'),
                          Text('100.000')
                        ]
          else if (product == "Producto 10")...[
            Text('Chaqueta En Jean Blanca'),
                            Text('50.000')
                          ]
        ],
      ),
    );
  }
}