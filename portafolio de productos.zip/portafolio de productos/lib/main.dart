import 'package:flutter/material.dart';
import 'presentation/my_app.dart';

void main() {
  runApp(const MyApp());
}
