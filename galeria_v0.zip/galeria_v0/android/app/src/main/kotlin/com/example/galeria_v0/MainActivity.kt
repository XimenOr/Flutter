package com.example.galeria_v0

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
