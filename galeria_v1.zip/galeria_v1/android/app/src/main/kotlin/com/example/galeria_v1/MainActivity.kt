package com.example.galeria_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
